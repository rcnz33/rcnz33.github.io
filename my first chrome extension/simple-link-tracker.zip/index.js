// let myLeads = ['www.example.com', 'www.epiclead.com', 'www.awesomeness33.com']
let myLeads = []

// localStorage.clear()

// Get DOM
const inputBtnEl = document.querySelector('#input-btn')
const clearBtnEl = document.querySelector('#clear-btn')
const inputEl = document.querySelector('#input-el')
const ulEl = document.querySelector('#ul-el')
const invalidURLEl = document.querySelector('#invalid-url-text')
const doubleClickInfoEl = document.querySelector('#double-click-info ')

// Only ON when (line 1) is ON
// let listedItems = ''
// for (eachItem of myLeads) {
//     listedItems += '<li>' + eachItem + '</li>'
// }
// console.log(listedItems)
// ulEl.innerHTML = listedItems


// GET LocalStorage
let leadsFromLocalStorage = JSON.parse(localStorage.getItem('myLeads'))
console.log(leadsFromLocalStorage)

if (localStorage.length > 0) {
    let tempoListedItems = ''
    for (eachItem of leadsFromLocalStorage) {
        tempoListedItems +=
        `<li>
            <a href="${eachItem}" target='_blank'>
                ${eachItem}
            </a>
        </li>`
    }
ulEl.innerHTML = tempoListedItems
myLeads = leadsFromLocalStorage
console.log(myLeads)
}


// Event Listeners
clearBtnEl.addEventListener('dblclick', function() {
    localStorage.clear()
    myLeads = []
    ulEl.innerHTML = null
})


inputBtnEl.addEventListener('click', function() {
    // this variable is use to validate the URL
    let tempoString = inputEl.value
    tempoString = tempoString.replace(/\s/g, '') // removes spaces

    console.log(tempoString)

    // Validate the URL
    if (tempoString.match(/(http(s)?:\/\/.)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/g) && !tempoString.includes(',')){
        myLeads.push((tempoString)) // stores in the array

        // ulEl.innerHTML += "<li><a href='" + myLeads[myLeads.length - 1] + "' target='_blank'>" + myLeads[myLeads.length - 1] + "</a></li>"
        
        // Display it on screen
        ulEl.innerHTML += `
        <li>
            <a href="${myLeads[myLeads.length - 1]}" target='_blank'>
                ${myLeads[myLeads.length - 1]}
            </a>
        </li>`
        // Reset
        inputEl.value = ''

        // Store it in the localStorage
        localStorage.setItem("myLeads", JSON.stringify(myLeads))

        // console.log(localStorage.getItem("myLeads"))

    } else {
        // The following code do: Pops up a message on the screen, displays wrong input of URL
        invalidURLEl.style.display = 'block'
        inputEl.style.border = 'thin solid red'
        inputEl.style.background = '#ffb0ad'
        setTimeout(function(){
            invalidURLEl.style.display = 'none'
            inputEl.style.background = 'rgb(255, 255, 255)'
            inputEl.style.border = 'solid thin rgba(0, 187, 0, 0.5)'
        }, 1500)
    }
    
})


// 
