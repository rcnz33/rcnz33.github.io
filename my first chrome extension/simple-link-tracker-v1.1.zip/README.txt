Monday, March 21, 2022 (1:28PM)

This is my first extension.
This is the first version of the extension.
First tested in Chrome browser.

Thanks for using! :)

More info, visit:  https://github.com/rcnz33